import React, { useEffect } from 'react';
import './PaymentForm.css'; 


function PaymentForm() {
    useEffect(() => {
        window.scrollTo(); 
    }, []);



const handlePayment = (event) => {
    event.preventDefault();
    alert('Payment successful!'); 
};

  return (
    <div className="payment-container">
      <h2 className="payment-header">Complete Your Payment</h2>
      <form onSubmit={handlePayment} className="payment-form">
        <input type="text" placeholder="Cardholder Name" />
        <input type="text" placeholder="Card Number" />
        <input type="text" placeholder="Expiration Date" />
        <input type="text" placeholder="CVC" />
        <button type="submit">Pay Now</button>
      </form>
    </div>
  );
};
export default PaymentForm;




