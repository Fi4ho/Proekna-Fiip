import mongoose from "mongoose";

export const  connectDB = async () =>{

    await mongoose.connect('mongodb+srv://fico:fico123456@cluster0.knjjg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0/Car Product').then(()=>console.log("DB Connected"));
}