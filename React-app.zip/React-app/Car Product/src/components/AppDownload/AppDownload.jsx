import React from 'react'
import './AppDownload.css'
import { assets } from '../../assets/assets'

const AppDownload = () => {
  return (
    <div className='app-download' id='app-download'>
      <p>For Better Expirience Download <br />Company Name</p>
      <div className="app-download-platfroms">
        <img src={assets.googleplay_store} alt="" />
        <img src={assets.appstore_icon} alt="" />
      </div>
    </div>
  )
}

export default AppDownload
